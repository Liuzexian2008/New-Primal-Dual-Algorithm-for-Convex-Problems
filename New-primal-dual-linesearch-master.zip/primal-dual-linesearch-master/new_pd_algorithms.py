
import numpy as np
import numpy.linalg as LA
from itertools import count
from time import process_time,perf_counter

def pd_new(J, prox_g, prox_f_conj, K, x0, y1, sigma, tau, numb_iter=100):
    """
        New-Primal-dual method for problem min_x max_y [
        <Kx,y> + g(x) - f*(y)].  Corresponds to Alg.1 in the paper.
     """
    begin = process_time()
    values = [J(x0, y1)]
    time_list = [process_time() - begin]
    iterates = [time_list, values, x0, y1,x0,y1]

    a=0.01
    b=1-a
    def T(time_list, values, x, y ,xag,yag):
        xag1 = b * xag + a * x
        yag1 = b * yag + a * y
        xmd = b * x + a * xag1
        ymd = b * y + a * yag1
        x1 = prox_g(xmd - tau* K.T.dot(y), tau)
        z = 2*x1 - x
        y1 = prox_f_conj(ymd + sigma*K.dot(z), sigma)

        values.append(J(x1, y1))
        time_list.append(process_time() - begin)
        res = [time_list, values, x1, y1, xag1,yag1]
        return res
    for i in range(numb_iter):
        iterates = T(*iterates)

    end = process_time()
    print("----- New primal-dual method----")
    print("Time execution:", end - begin)
    return iterates[:4]


def pd_new_accelerate_dual(J, prox_g, prox_f_conj, K,  x0, y1,  tau,sigma,gamma, numb_iter=100):
    """
    Accelerated New-Primal-dual method  for problem
    min_x max_y [<Kx,y>  + g(x) - f*(y)], where f* is gamma-strongly convex
    """
    begin = process_time()  # process_time()
    x, y,xag,yag = x0, y1, x0,y1
    values = [J(x0, y1)]
    a=0.005
    b=1-a
    time_list = [process_time() - begin]
    for i in range(numb_iter):
        xag1 = b * xag + a * x
        yag1 = b * yag + a * y

        xmd = b * x + a * xag1
        ymd = b * y + a * yag1

        x1 = prox_g(xmd - tau * K.T.dot(y), tau)
        theta = 1. / np.sqrt(1 + gamma * sigma)
        sigma  *= theta
        tau *= 1./theta
        z = x1 + theta * (x1 - x)
        y1 = prox_f_conj(ymd + sigma * K.dot(z), sigma)

        x = x1
        y = y1
        xag = xag1
        yag = yag1
        values.append(J(x, y))

        time_list.append(process_time() - begin)
    end =process_time() # process_time()
    print("----- Accelerated new primal-dual method (f^*(y) is strongly convex) -----")
    print("Time execution:", end - begin)
    return [time_list, values, x, y]



def pd_new_linesearch_dual_is_square_norm(J, prox_g, b, K,  x0, y1, tau,beta, numb_iter=100):
    """ New-Primal-dual method with linesearch for min_x max_y [ <Kx,y> + g(x) - f*(y) ]
    for the case when f*(y) = 0.5||y-b||^2. Corresponds to Alg.3 in the paper.
    beta denotes sigma/tau from a classical primal-dual algorithm.
    """
    begin = process_time()
    theta = 1
    values = [J(x0, y1)]
    time_list = [process_time() - begin]
    mu = 0.7
    delta = 0.96
    Kx0 = K.dot(x0)
    iterates = [time_list, values, x0, y1,
                theta, tau, Kx0, K.T.dot(Kx0),K.T.dot(y1),x0]
    sqrt_beta = np.sqrt(beta)
    KTb = K.T.dot(b)
    a=0.01
    def T(time_list, values, x_old, y, th_old, tau_old, Kx_old, KTKx_old,KTy,xag):
        # Note that KTy = K.T.dot(y)
        xag1 = (1 - a) * xag + a * x_old
        xmd = (1 - a) * x_old + a* xag1
        x = prox_g(xmd - tau_old * KTy, tau_old)
        Kx = K.dot(x)
        KTKx = K.T.dot(Kx)
        th = np.sqrt(1 + th_old)
        for j in count(0):
            tau = tau_old * th
            sigma = tau * beta
            z = x + th * (x - x_old)
            Kz = Kx + th * (Kx - Kx_old)
            y1 = (y + sigma * (Kz + b)) / (1. + sigma)
            KTKz = (1 + th) * KTKx - th * KTKx_old
            KTy1 = (KTy + sigma * (KTKz + KTb)) / (1. + sigma)
            if sqrt_beta * tau * LA.norm(KTy1 - KTy) <= delta * LA.norm(y1 - y):
                break
            else:
                th *= mu
        values.append(J(x, y1))
        time_list.append(process_time() - begin)
        res = [time_list, values, x, y1, th, tau, Kx, KTKx,KTy1,xag1]
        return res

    for i in range(numb_iter):
        iterates = T(*iterates)
    end = process_time()
    print(
        "----- New primal-dual method with linesearch ( f^*(y)=0.5*||y-b||^2)-----")
    print("Time execution:", end - begin)
    return iterates[:4]


def pd_new_linesearch(J, prox_g, prox_f_conj, K, x0, y1, tau, beta, numb_iter=100):
    """New-Primal-dual method with linesearch for problem min_x max_y [
    <Kx,y> + g(x) - f*(y)].  Corresponds to Alg.3 in the paper.
    beta denotes sigma/tau from a classical primal-dual algorithm.
    """
    begin = process_time()
    theta = 1
    values = [J(x0, y1)]
    time_list = [process_time() - begin]
    mu = 0.7
    delta = 0.96
    iterates = [time_list, values, x0, y1, theta, tau, K.dot(x0), x0, y1]
    sqrt_b = np.sqrt(beta)

    a = 0.01
    b = 1 - a

    def T(time_list, values, x_old, y, th_old, tau_old, Kx_old, xag, yag):
        xag1 = (1 - a) * xag + a * x_old
        yag1 = (1 - a) * yag + a * y
        xmd = b * x_old + a * xag1
        ymd = b * y + a * yag1
        x = prox_g(xmd - tau_old * K.T.dot(y), tau_old)
        Kx = K.dot(x)
        th = np.sqrt(1 + th_old)
        for j in count(0):
            tau = tau_old * th
            # z = x + th * (x - x_old)
            Kz = Kx + th * (Kx - Kx_old)
            y1 = prox_f_conj(ymd + tau * beta * Kz, tau * beta)
            ytmp = y1 - y
            if sqrt_b * tau * LA.norm(K.T.dot(ytmp)) <= delta * LA.norm(ytmp):
                break
            else:
                th *= mu
        values.append(J(x, y1))
        time_list.append(process_time() - begin)
        res = [time_list, values, x, y1, th, tau, Kx, xag1, yag1]
        return res

    for i in range(numb_iter):
        iterates = T(*iterates)

    end = process_time()
    print("----- New primal-dual method with linesearch-----")
    print("Time execution:", end - begin)
    return iterates[:4]



